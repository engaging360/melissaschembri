
(function(a){a(document).ready(function(){if(!a("html").hasClass("is-builder"))a(".mbr-gallery-item").on("click","a",function(b){a(this)[0].hasAttribute("data-target")&&""!==a(this).attr("data-target")&&a("#"+a(this).attr("data-target").replace("#","")).modal("show")})})})(jQuery);
