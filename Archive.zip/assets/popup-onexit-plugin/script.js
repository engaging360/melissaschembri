
(function(a){a(document).ready(function(){if(!a("html").hasClass("is-builder")){var b=!0;a(document).mouseleave(function(){b&&(a(".mbr-popup[data-on-exit]").each(function(b,c){a(c).modal("show")}),b=!1)})}})})(jQuery);
